create function valid_player_deployment (@player_id UNIQUEIDENTIFIER, @playing_team_id UNIQUEIDENTIFIER) returns bit AS
BEGIN
    if (exists
    (select 1 from player inner join playing_team
    on (player.id = @player_id AND playing_team.id = @playing_team_id) AND
    player.global_team_id = playing_team.global_team_id))
        return 1
    return 0
END
go

