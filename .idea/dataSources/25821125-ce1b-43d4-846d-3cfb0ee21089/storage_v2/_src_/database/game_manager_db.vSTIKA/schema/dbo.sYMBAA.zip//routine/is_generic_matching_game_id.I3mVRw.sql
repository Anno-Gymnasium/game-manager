create function is_generic_matching_game_id (@id UNIQUEIDENTIFIER) returns bit AS
BEGIN
    if (exists(select 1 from generic_matching_game where generic_matching_game.id = @id))
        return 1
    return 0
END
go

