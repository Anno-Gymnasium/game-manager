create function game_id_is_tree_game_id (@playing_team_id UNIQUEIDENTIFIER) returns bit AS
BEGIN
    if (exists
    (select 1 from playing_team inner join
    tree_game on playing_team.id = @playing_team_id AND playing_team.game_id = tree_game.id))
        return 1
    return 0
END
go

