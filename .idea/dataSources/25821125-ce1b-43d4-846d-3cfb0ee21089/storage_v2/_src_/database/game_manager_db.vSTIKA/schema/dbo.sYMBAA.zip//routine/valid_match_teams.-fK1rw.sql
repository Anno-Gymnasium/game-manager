create function valid_match_teams (@gmt_1_id UNIQUEIDENTIFIER, @gmt_2_id UNIQUEIDENTIFIER) returns bit AS
BEGIN
    if (@gmt_1_id != @gmt_2_id AND exists
    (select 1 from playing_team p1 inner join playing_team p2
    on (p1.id = @gmt_1_id AND p2.id = @gmt_2_id)
    AND p1.game_id = p2.game_id
    AND p1.league_index = p2.league_index))
        return 1
    return 0
END
go

