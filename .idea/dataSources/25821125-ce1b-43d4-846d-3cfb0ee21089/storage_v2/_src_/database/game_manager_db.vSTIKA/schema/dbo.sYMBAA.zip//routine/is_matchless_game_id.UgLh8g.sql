create function is_matchless_game_id (@id UNIQUEIDENTIFIER) returns bit AS
BEGIN
    if (exists(select 1 from matchless_game where matchless_game.id = @id))
        return 1
    return 0
END
go

