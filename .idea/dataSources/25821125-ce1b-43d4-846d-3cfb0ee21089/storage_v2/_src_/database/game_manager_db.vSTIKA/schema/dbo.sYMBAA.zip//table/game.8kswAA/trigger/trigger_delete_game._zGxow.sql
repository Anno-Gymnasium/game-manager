create trigger trigger_delete_game
on game instead of delete
AS

delete playing_team from playing_team inner join deleted
on playing_team.game_id = deleted.id

delete game from game inner join deleted
on game.id = deleted.id
go

